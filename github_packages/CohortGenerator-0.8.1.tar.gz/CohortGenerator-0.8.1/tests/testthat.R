library(testthat)
library(CohortGenerator)

test_check("CohortGenerator")
