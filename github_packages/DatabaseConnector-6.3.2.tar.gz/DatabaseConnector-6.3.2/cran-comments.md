This update includes 1 bugfix. (see NEWS.md).

---

## Test environments
* Ubuntu 20.04, R 4.3.1
* MacOS, R 4.2.3
* MacOS, 4.3.1
* Windows 10, R 4.3.1

## R CMD check results

There were no ERRORs or WARNINGs. 

## Downstream dependencies

DatabaseConnector is used by Achilles, CohortAlgebra, CohortExplorer, TreatmentPatterns, and CDMConnector, which were tested with this new version. No issues were found.