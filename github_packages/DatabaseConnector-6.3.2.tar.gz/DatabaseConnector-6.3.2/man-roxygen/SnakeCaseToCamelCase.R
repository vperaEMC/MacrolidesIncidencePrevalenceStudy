#' @param snakeCaseToCamelCase If true, field names are assumed to use snake_case, and are converted to camelCase.
