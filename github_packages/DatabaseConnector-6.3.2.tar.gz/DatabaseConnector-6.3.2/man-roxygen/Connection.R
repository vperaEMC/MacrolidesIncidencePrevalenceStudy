#' @param connection The connection to the database server created using either
#'                   [connect()] or [dbConnect()].
