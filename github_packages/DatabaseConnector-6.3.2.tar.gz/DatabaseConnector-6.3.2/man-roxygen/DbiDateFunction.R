#' @description 
#' This function is provided primarily to be used together with `dbplyr` when querying 
#' a database. It will also work in `dplyr` against data frames.
