## R CMD check results

This is a resubmission of an new cran package.



One NOTE is expected. One package that enhances Capr is not on CRAN.

A couple examples are wrapped in \dontrun because they rely on an external data
source to work correctly. 

RCMD check passed on the following platforms with 0 errors, 0 warnings, and 0 notes 

 Github Actions runners
  - {os: macOS-latest,   r: 'release'}
  - {os: windows-latest, r: 'release'}
  - {os: ubuntu-latest,   r: 'release'}
  - {os: ubuntu-latest,   r: 'devel'}

Mac OS 12.6 running R 4.2.2

I also checked on winbuilder 
