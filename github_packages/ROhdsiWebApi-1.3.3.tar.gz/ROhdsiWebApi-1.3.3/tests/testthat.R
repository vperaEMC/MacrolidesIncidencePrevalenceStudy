library(testthat)
library(ROhdsiWebApi)

test_check("ROhdsiWebApi")
