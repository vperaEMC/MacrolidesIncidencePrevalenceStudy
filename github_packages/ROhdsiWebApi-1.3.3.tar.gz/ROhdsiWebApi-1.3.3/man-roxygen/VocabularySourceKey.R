#' @param vocabularySourceKey   The source key of the Vocabulary. By default, the priority Vocabulary is
#'                         used.
