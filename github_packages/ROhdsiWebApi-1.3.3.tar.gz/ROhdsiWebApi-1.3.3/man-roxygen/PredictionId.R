#' @param predictionId   An integer id representing the id that uniquely identifies a prediction definition
#'                       in a WebApi instance.

