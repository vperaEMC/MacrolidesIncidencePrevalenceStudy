#' @param characterizationId   An integer id representing the id that uniquely identifies a 
#'                           characterization analysis definition in a WebApi instance.

