#' @param estimationId    An integer id representing the id that uniquely identifies a estimation analysis definition
#'                        in a WebApi instance.

