#' @param conceptSetDefinition       A concept set definition, for example as obtained through the \code{\link{getConceptSetDefinition}} function, 
#'                         or taken from a cohort definition.
