#' @param category    These are the categories in WebApi. The valid string options are 'conceptSet', 
#'                    'cohort', 'characterization', 'pathway, 'incidenceRate', 'estimation', 'prediction'.



