#' @param pathwayId       An integer id representing the id that uniquely identifies a pathway analysis definition
#'                        in a WebApi instance.
