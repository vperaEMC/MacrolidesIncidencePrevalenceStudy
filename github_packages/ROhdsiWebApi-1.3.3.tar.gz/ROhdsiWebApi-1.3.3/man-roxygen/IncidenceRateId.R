#' @param incidenceRateId An integer id representing the id that uniquely identifies a incidence rate analysis definition
#'                        in a WebApi instance.

