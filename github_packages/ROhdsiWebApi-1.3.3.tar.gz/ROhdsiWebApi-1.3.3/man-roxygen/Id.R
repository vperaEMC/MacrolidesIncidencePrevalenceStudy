#' @param id       An integer id representing the id that uniquely identifies a 
#'                 definition for the category in a WebApi instance.


