#' @param cohortId       An integer id representing the id that uniquely identifies a cohort definition
#'                       in a WebApi instance.

