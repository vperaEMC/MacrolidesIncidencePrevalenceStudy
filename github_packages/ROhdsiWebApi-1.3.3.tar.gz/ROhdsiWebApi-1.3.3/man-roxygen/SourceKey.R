#' @param sourceKey      The source key for a CDM instance in WebAPI, as defined in the
#'                       Configuration page
