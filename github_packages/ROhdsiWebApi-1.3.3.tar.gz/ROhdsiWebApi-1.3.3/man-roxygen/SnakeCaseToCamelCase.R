#' @param snakeCaseToCamelCase  Should the column names of the result be converted to camelCase? 
